Config = {}

Config.Language = {
    ['drag'] = 'Drag Person',
    ['carry'] = 'Carry Person',
    ['release'] = 'Release Person',
    ['being_dragged'] = 'You are being dragged',
    ['being_carried'] = 'You are being carried'
}

-- Animations
Config.Animations = {
    drag = {
        dict = 'combat@drag_ped@',
        anim = 'drag_ped_loop',
        t_dict = 'combat@drag_ped@', -- Target dictionary
        t_anim = 'drag_ped_target_loop' -- Target animation
    },
    carry = {
        dict = 'missfinale_c2mcs_1',
        anim = 'fin_c2_mcs_1_camman',
        t_dict = 'nm',
        t_anim = 'fireman_carry'
    }
}
