local dragging = {}
local carrying = {}

-- Events
RegisterNetEvent('crx_dragncarry:server:requestDrag', function(targetId)
    local source = source
    local target = targetId
    
    if target ~= 0 and GetPlayerPing(target) > 0 then
        -- Notify Source (Dragger)
        TriggerClientEvent('crx_dragncarry:client:startDrag', source, target)
        -- Notify Target (Victim)
        TriggerClientEvent('crx_dragncarry:client:setDragged', target, source)
        
        dragging[source] = target
    end
end)

RegisterNetEvent('crx_dragncarry:server:requestCarry', function(targetId)
    local source = source
    local target = targetId
    
    if target ~= 0 and GetPlayerPing(target) > 0 then
        TriggerClientEvent('crx_dragncarry:client:startCarry', source, target)
        TriggerClientEvent('crx_dragncarry:client:setCarried', target, source)
        
        carrying[source] = target
    end
end)

RegisterNetEvent('crx_dragncarry:server:stopDrag', function(targetId)
    local source = source
    local target = targetId
    
    if target and target ~= 0 then
        TriggerClientEvent('crx_dragncarry:client:stop', target)
    end
    dragging[source] = nil
end)

RegisterNetEvent('crx_dragncarry:server:stopCarry', function(targetId)
    local source = source
    local target = targetId
    
    if target and target ~= 0 then
        TriggerClientEvent('crx_dragncarry:client:stop', target)
    end
    carrying[source] = nil
end)

-- Handle Disconnects
AddEventHandler('playerDropped', function()
    local source = source
    
    -- If this player was dragging someone, free the victim
    if dragging[source] then
        local target = dragging[source]
        TriggerClientEvent('crx_dragncarry:client:stop', target)
        dragging[source] = nil
    end
    
    -- If this player was carrying someone, free the victim
    if carrying[source] then
        local target = carrying[source]
        TriggerClientEvent('crx_dragncarry:client:stop', target)
        carrying[source] = nil
    end
end)
