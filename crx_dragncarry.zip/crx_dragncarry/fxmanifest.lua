fx_version 'cerulean'
game 'gta5'

author 'I_AM_FULLYCRX/fullcrxstiano_7'
description 'Drag and Carry script with ox_target support'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'ox_target',
    'ox_lib'
}
