local isDragging = false
local isCarrying = false
local isBeingDragged = false
local isBeingCarried = false
local draggedBy = nil
local carriedBy = nil

-- OX Target Integration
exports.ox_target:addGlobalPlayer({
    {
        name = 'crx_drag',
        label = Config.Language['drag'],
        icon = 'fa-solid fa-hand-holding',
        onSelect = function(data)
            TriggerServerEvent('crx_dragncarry:server:requestDrag', GetPlayerServerId(NetworkGetPlayerIndexFromPed(data.entity)))
        end,
        canInteract = function(entity, distance, coords, name)
            return not isDragging and not isCarrying and not isBeingDragged and not isBeingCarried
        end
    },
    {
        name = 'crx_carry',
        label = Config.Language['carry'],
        icon = 'fa-solid fa-person-arrow-up-from-line',
        onSelect = function(data)
            TriggerServerEvent('crx_dragncarry:server:requestCarry', GetPlayerServerId(NetworkGetPlayerIndexFromPed(data.entity)))
        end,
        canInteract = function(entity, distance, coords, name)
            return not isDragging and not isCarrying and not isBeingDragged and not isBeingCarried
        end
    }
})

-- UTILS
local function LoadAnimDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(5)
    end
end

-- SERVER REQUEST HANDLERS
RegisterNetEvent('crx_dragncarry:client:startDrag', function(targetId)
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))
    isDragging = true
    draggedBy = nil -- We are the dragger
    
    LoadAnimDict(Config.Animations.drag.dict)
    
    -- Main Loop for Dragger
    CreateThread(function()
        while isDragging do
            Wait(0)
            if not IsEntityPlayingAnim(PlayerPedId(), Config.Animations.drag.dict, Config.Animations.drag.anim, 3) then
                TaskPlayAnim(PlayerPedId(), Config.Animations.drag.dict, Config.Animations.drag.anim, 8.0, -8.0, 100000, 49, 0, false, false, false)
            end

            -- Disable Pause Menu
            DisableControlAction(0, 199, true) -- P
            DisableControlAction(0, 200, true) -- ESC

            -- Release Controls
            if IsDisabledControlJustPressed(0, 200) or IsDisabledControlJustPressed(0, 199) or IsControlJustPressed(0, 177) then -- ESC, P, or Backspace
                TriggerServerEvent('crx_dragncarry:server:stopDrag', targetId)
                isDragging = false
                ClearPedTasks(PlayerPedId())
            end
        end
    end)
end)

RegisterNetEvent('crx_dragncarry:client:startCarry', function(targetId)
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))
    isCarrying = true
    
    LoadAnimDict(Config.Animations.carry.dict)
    
    -- Main Loop for Carrier
    CreateThread(function()
        while isCarrying do
            Wait(0)
            if not IsEntityPlayingAnim(PlayerPedId(), Config.Animations.carry.dict, Config.Animations.carry.anim, 3) then
                TaskPlayAnim(PlayerPedId(), Config.Animations.carry.dict, Config.Animations.carry.anim, 8.0, -8.0, 100000, 49, 0, false, false, false)
            end

            -- Disable Pause Menu
            DisableControlAction(0, 199, true) -- P
            DisableControlAction(0, 200, true) -- ESC

            -- Release Controls
            if IsDisabledControlJustPressed(0, 200) or IsDisabledControlJustPressed(0, 199) or IsControlJustPressed(0, 177) then
                TriggerServerEvent('crx_dragncarry:server:stopCarry', targetId)
                isCarrying = false
                ClearPedTasks(PlayerPedId())
            end
        end
    end)
end)

-- RECEIVING END HANDLERS (The Victim)

RegisterNetEvent('crx_dragncarry:client:setDragged', function(draggerId)
    local draggerPed = GetPlayerPed(GetPlayerFromServerId(draggerId))
    isBeingDragged = true
    draggedBy = draggerId

    LoadAnimDict(Config.Animations.drag.t_dict)
    
    -- Attach logic
    AttachEntityToEntity(PlayerPedId(), draggerPed, 11816, 0.45, 0.45, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
    
    -- Anti-Glitch / Control Disable Loop
    CreateThread(function()
        while isBeingDragged do
            Wait(0)
            
            -- Force Animation
            if not IsEntityPlayingAnim(PlayerPedId(), Config.Animations.drag.t_dict, Config.Animations.drag.t_anim, 3) then
                TaskPlayAnim(PlayerPedId(), Config.Animations.drag.t_dict, Config.Animations.drag.t_anim, 8.0, -8.0, 100000, 1, 0, false, false, false)
            end
            
            -- Disable Controls to prevent cancelling
            DisableControlAction(0, 73, true) -- X (Cancel Emote)
            DisableControlAction(0, 323, true) -- X (Alternative)
            DisableControlAction(0, 22, true) -- Jump
            DisableControlAction(0, 23, true) -- Enter Vehicle
            DisableControlAction(0, 24, true) -- Attack
            DisableControlAction(0, 25, true) -- Aim
            DisableControlAction(0, 30, true) -- Move LR
            DisableControlAction(0, 31, true) -- Move UD
            DisableControlAction(0, 257, true) -- Attack 2
            DisableControlAction(0, 263, true) -- Melee Attack 1
            DisableControlAction(0, 264, true) -- Melee Attack 2
            
            -- If for some reason they get detached (e.g. forced by another script), re-attach? 
            -- Better to let the server stop event handle detachment, but we can ensure they stay close?
            -- Rely on AttachEntityToEntity for position.
        end
    end)
end)

RegisterNetEvent('crx_dragncarry:client:setCarried', function(carrierId)
    local carrierPed = GetPlayerPed(GetPlayerFromServerId(carrierId))
    isBeingCarried = true
    carriedBy = carrierId
    
    LoadAnimDict(Config.Animations.carry.t_dict)
    
    -- Attach Logic
    -- Offset for shoulder carry
    AttachEntityToEntity(PlayerPedId(), carrierPed, 0, 0.27, 0.15, 0.63, 0.5, 0.5, 180, false, false, false, false, 2, false)

    -- Anti-Glitch / Control Disable Loop
    CreateThread(function()
        while isBeingCarried do
            Wait(0)
            
            if not IsEntityPlayingAnim(PlayerPedId(), Config.Animations.carry.t_dict, Config.Animations.carry.t_anim, 3) then
                TaskPlayAnim(PlayerPedId(), Config.Animations.carry.t_dict, Config.Animations.carry.t_anim, 8.0, -8.0, 100000, 1, 0, false, false, false)
            end
            
            -- Disable Controls
            DisableControlAction(0, 73, true) -- X
            DisableControlAction(0, 323, true) -- X
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 23, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 30, true) 
            DisableControlAction(0, 31, true)
            
            -- Disable Escape Menu for victim too? Optional, but usually good to let them access settings.
            -- Prompt says "when players press escape it doesn't trigger the pause menu... ONLY the button should still function". 
            -- This usually applies to the CARRIER so they can cancel. The victim should arguably be helpless. 
            -- We will leave ESC enabled for victim so they can exit game if needed, but disable movement/anim cancel.
        end
    end)
end)

RegisterNetEvent('crx_dragncarry:client:stop', function()
    isDragging = false
    isCarrying = false
    isBeingDragged = false
    isBeingCarried = false
    draggedBy = nil
    carriedBy = nil
    
    DetachEntity(PlayerPedId(), true, false)
    ClearPedTasks(PlayerPedId())
end)
